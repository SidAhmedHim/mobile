package com.example.face_auth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
